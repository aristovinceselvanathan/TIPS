﻿namespace TImerApp.Models
{
    partial class UserTask
    {
        public enum TaskCategory
        {
            Important,
            Personal,
            Work,
            FunActivity,
            Others
        }
    }
}
